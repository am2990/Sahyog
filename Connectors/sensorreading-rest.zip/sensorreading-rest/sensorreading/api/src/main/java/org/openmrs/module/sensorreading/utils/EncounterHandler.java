package org.openmrs.module.sensorreading.utils;

public class EncounterHandler {

}
